@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-12 col-lg-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Manage Medicines</h3>
            </div>
            <div class="card-body">
                <a href="{{ route('medicine.create') }}" class="btn btn-block btn-info">
                    <i class="fa fa-plus"></i>
                    Create Medicine
                </a>
                
               
                
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered text-nowrap w-100">
                            <thead>
                                <tr>
                                    <th class="wd-15p">SL.NO</th>
                                    <th class="wd-15p">Medicine Code</th>
                                    <th class="wd-20p">Medicine Name </th>
                                    <th class="wd-15p">Generic Name</th>
                                    <th class="wd-15p">Medicine Category</th>
                                    <th class="wd-15p">Unit</th>
                                    <th class="wd-15p">Has Batch</th>
                                    <th class="wd-15p">Sale Rate</th>
                                    <th class="wd-15p">Tax</th>
                                    <th class="wd-15p">Reorder Level</th>
                                    <th class="wd-15p">Allow Batch</th>
                                    <th class="wd-15p">Remarks</th>
                                    <th class="wd-15p">Status</th>
                                    <th class="wd-15p">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                $i = 0;
                                @endphp
                                @foreach($medicines as $medicine)
                                <tr>
                                    <td>{{ ++$i }}</td>
                                    <td>{{ $medicine->medicine_code }}</td>
                                    <td>{{ $medicine->medicine_name }}</td>
                                    <td>{{ $medicine->generic_name}}</td>
                                    <td>{{ $medicine->medicinecategory->category_name}}</td>
                                    <td>{{ $medicine->unit->unit_name}}</td>
                                    <td>{{ $medicine->has_batch}}</td>
                                    <td>{{ $medicine->sale_rate}}</td>
                                    <td>{{ $medicine->tax->tax_name}}</td>
                                    <td>{{ $medicine->reorder_level}}</td>
                                    <td>{{ $medicine->allow_batch}}</td>
                                    <td>{{ $medicine->remarks}}</td>

                                    <td>
                                        <form action="{{ route('medicine.changeStatus', $medicine->id) }}" method="POST">
                                        @csrf
                                        @method('PATCH')
                                            <button type="submit"
                                                onclick="return confirm('Do you want to Change status?');"
                                                class="btn btn-sm @if($medicine->is_active == 0) btn-danger @else btn-success @endif">
                                                @if($medicine->is_active == 0)
                                                InActive
                                                @else
                                                Active
                                                @endif
                                            </button>
                                        </form>
                                    </td>
                                       
                                    <td>
                                        <a class="btn btn-secondary"
                                            href="{{ route('medicine.edit', $medicine->id) }}"><i
                                                class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit </a>
                                        <form style="display: inline-block"
                                            action="{{ route('medicine.destroy', $medicine->id) }}" method="post">
                                            @csrf
                                            @method('delete')
                                            <button type="submit" class="btn btn-danger"><i class="fa fa-trash"
                                                    aria-hidden="true"></i>Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                
                <!-- TABLE WRAPPER -->
            </div>
            <!-- SECTION WRAPPER -->
        </div>
    </div>
</div>
<!-- ROW-1 CLOSED -->
@endsection



