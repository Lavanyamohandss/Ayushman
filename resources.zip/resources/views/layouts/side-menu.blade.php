 <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
 <aside class="app-sidebar">
     <div class="side-header">
         <a class="header-brand1" href="#">
             <img src="{{asset('assets/images/ayushman-logo.jpeg')}}" class="header-brand-img desktop-logo" alt="logo">
             <img src="{{asset('assets/images/ayushman-logo.jpeg')}}" class="header-brand-img toggle-logo" alt="logo">
             <img src="{{asset('assets/images/ayushman-logo.jpeg')}}" class="header-brand-img light-logo" alt="logo">
             <img src="{{asset('assets/images/ayushman-logo.jpeg')}}" class="header-brand-img light-logo1" alt="logo">
         </a><!-- LOGO -->
         <a aria-label="Hide Sidebar" class="app-sidebar__toggle ml-auto" data-toggle="sidebar" href="#"></a><!-- sidebar-toggle-->
     </div>
    <div class="app-sidebar__user">
    <div class="dropdown user-pro-body text-center">
        <div class="user-pic">
            @if(auth()->user()->image)
                <img src="{{ auth()->user()->image_url }}" alt="user-img" class="avatar-xl rounded-circle">
            @else
                <img src="{{ asset('assets/images/avatar.png') }}" alt="user-img" class="avatar-xl rounded-circle">
            @endif
        </div>
        <div class="user-info">
            <h6 class="mb-0 text-dark">{{ ucfirst(auth()->user()->admin_name) }}</h6>
            <span class="text-muted app-sidebar__user-name text-sm">Administrator</span>
        </div>
    </div>
</div>

     <div class="sidebar-navs">
         <ul class="nav nav-pills-circle ">
             <li class="nav-item" data-toggle="tooltip" data-placement="top" title="Logout">
                 <a href="{{route('logout')}}" class="nav-link text-center m-2">
                     <i class="fe fe-power"></i>
                 </a>
             </li>
         </ul>
     </div> 
     <ul class="side-menu">
         <li class="slide">
             <a class="side-menu__item @yield('admin')" href="{{route('home')}}"><i class="side-menu__icon ti-home"></i><span class="side-menu__label">Dashboard</span></a>
         </li>
         
     </ul>
      <li class="slide">
        <a class="side-menu__item"  data-toggle="slide" href="#"><i class="side-menu__icon ti-panel"></i><span class="side-menu__label">{{ __('Masters') }}</span><i class="angle fa fa-angle-right"></i></a>
        <ul class="slide-menu">
                      <li><a class="slide-item" href="{{ url('/branches') }}">{{ __('Branches') }}</a></li>
                      <li><a class="slide-item" href="{{ url('/users/index')}}">{{ __('Users') }}</a></li>
                      <li><a class="slide-item" href="#">{{ __('Manage Staffs') }}</a></li>
                      <li><a class="slide-item" href="{{ url('/therapyrooms/index') }}">{{ __('Therapy Rooms') }}</a></li>
                      <li><a class="slide-item" href="{{ url('/externaldoctors/index')}}">{{ __('External Doctors') }}</a></li>
                      <li><a class="slide-item" href="{{ url('/patients/index')}}">{{ __('Patients') }}</a></li>
                      <li><a class="slide-item" href="{{ url('/timeslot')}}">{{ __('Timeslots') }}</a></li>
                      <li><a class="slide-item" href="{{ url('/medicine/index') }}">{{ __('Medicines') }}</a></li>
                      <li><a class="slide-item" href="{{ url('/medicinecategory/index') }}">{{ __('Medicine Categories') }}</a></li>
                      <li><a class="slide-item" href="{{ url('/therapies/index')}}">{{ __('Therapy') }}</a></li>
                      <li><a class="slide-item" href="{{ url('membership/index')}}">{{ __('Memberships') }}</a></li>
                      <li><a class="slide-item" href="{{ url('wellness/index')}}">{{ __('Wellness') }}</a></li>
                      <li><a class="slide-item" href="{{ url('/unit/index')}}">{{ __('Units') }}</a></li>
                      <li><a class="slide-item" href="{{ url('/tax/index')}}">{{ __('Taxes') }}</a></li>
                      
        </li>
      </ul>
       <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti-receipt"></i>
          <span class="side-menu__label"> {{ __('Billings') }}</span><i class="angle fa fa-angle-right"></i>
        </a>
        <ul class="slide-menu">
             <li><a class="slide-item" href="{{ url('/consultation-billing/index')}}">{{__('Consultation Billing')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Wellness Billing')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Therapy Billing')}}</a></li>
      </li>
      </ul>

       <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti-check-box"></i>
          <span class="side-menu__label"> {{ __('Settlements') }}</span><i class="angle fa fa-angle-right"></i>
        </a>
        <ul class="slide-menu">
             <li><a class="slide-item" href="#">{{__('Invoice Settlement')}}</a></li>
        </li>
      </ul>


       <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti-crown"></i>
          <span class="side-menu__label"> {{ __('Membership') }}</span><i class="angle fa fa-angle-right"></i>
        </a>
        <ul class="slide-menu">
             <li><a class="slide-item" href="#">{{__('Manage Patient Memberships')}}</a></li>
        </li>
      </ul>

              
         <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti-comment"></i>
          <span class="side-menu__label"> {{ __('Message Center') }}</span>
        </a>
    </li>
      


      <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon fa fa-users"></i>
          <span class="side-menu__label"> {{ __('Consultation') }}</span>
        </a>
      </li>

       <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti-heart"></i>
          <span class="side-menu__label"> {{ __('Wellness') }}</span>
        </a>
      </li>

      <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon fa fa-heart"></i>
          <span class="side-menu__label"> {{ __('Therapy') }}</span><i class="angle fa fa-angle-right"></i>
        </a>
        <ul class="slide-menu">
             <li><a class="slide-item" href="#">{{__('Manage Therapy')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Therapy Refund')}}</a></li>
        </li>
      </ul> 

       <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti-user"></i>
          <span class="side-menu__label"> {{ __('Patients') }}</span>
        </a>
      </li>

       <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti-id-badge"></i>
          <span class="side-menu__label"> {{ __('Staffs') }}</span><i class="angle fa fa-angle-right"></i>
        </a>
        <ul class="slide-menu">
             <li><a class="slide-item" href="#">{{__('Staff Attendence View')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Staff Leaves')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Staff Leave Marking')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Advance Salary')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Salary Processing')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Staff Cash Deposit')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Employee Branch Transfer')}}</a></li>
      </li>
      </ul>

      <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti-package"></i>
          <span class="side-menu__label"> {{ __('Suppliers') }}</span><i class="angle fa fa-angle-right"></i>
        </a>
        <ul class="slide-menu">
             <li><a class="slide-item" href="#">{{__('Manage Suppliers')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Stock Transfer to Other Branches')}}</a></li>
        </li>
      </ul> 

       <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti-credit-card"></i>
          <span class="side-menu__label"> {{ __('Purchase') }}</span><i class="angle fa fa-angle-right"></i>
        </a>
        <ul class="slide-menu">
             <li><a class="slide-item" href="#">{{__('Medicine Purchase')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Purchase Return')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Medicine Stock Updation')}}</a></li>
        </li>
      </ul> 


       <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti-bar-chart"></i>
          <span class="side-menu__label"> {{ __('Sales') }}</span><i class="angle fa fa-angle-right"></i>
        </a>
        <ul class="slide-menu">
             <li><a class="slide-item" href="#">{{__('Medicine Sales')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Sales Return')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Medicine Stock Transfer To Therapy')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Prescription Printing')}}</a></li>
        </li>
      </ul> 

      <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti-wallet"></i>
          <span class="side-menu__label"> {{ __('Accounts') }}</span><i class="angle fa fa-angle-right"></i>
        </a>
        <ul class="slide-menu">
             <li><a class="slide-item" href="#">{{__('Account Subhead')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Journel Entry')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Attendence View-Biometric')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Income/Expense')}}</a></li>
        </li>
      </ul>
       
         <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti-settings"></i>
          <span class="side-menu__label"> {{ __('Settings') }}</span><i class="angle fa fa-angle-right"></i>
        </a>
        <ul class="slide-menu">
             <li><a class="slide-item" href="#">{{__('Manage Admin Settings')}}</a></li>
        </li>
      </ul> 


       <li class="slide">
        <a class="side-menu__item" data-toggle="slide" href="#">
          <i class="side-menu__icon ti ti-file"></i>
          <span class="side-menu__label"> {{ __('Reports') }}</span><i class="angle fa fa-angle-right"></i>
        </a>
        <ul class="slide-menu">
             <li><a class="slide-item" href="#">{{__('Sales Report')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Purchase Report')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Stock Transfer Report')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Current Stock Report')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Payment Received Report')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Payment Made Report')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Receivable Report')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Payable Report')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Ledger Report')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Profit and Loss Report')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Trail Balance Report')}}</a></li>
             <li><a class="slide-item" href="#">{{__('Balance Sheet Report')}}</a></li>
            
      </li>
      </ul>

         <li class="slide">
        <a class="side-menu__item"  data-toggle="slide" href="#"><i class="side-menu__icon fa fa-user"></i><span class="side-menu__label">{{ __('Profile') }}</span><i class="angle fa fa-angle-right"></i></a>
        <ul class="slide-menu">
                      <li><a class="slide-item" href="#">{{ __('Update Profile') }}</a></li>
                      <li><a class="slide-item" href="#">{{ __('Change Password') }}</a></li>
                      <li><a class="slide-item" href="#">{{ __('Logout') }}</a></li>

         </li>
      </ul>

 </aside>