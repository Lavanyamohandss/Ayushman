@extends('layouts.app')
@section('content')
<div class="container">
   <div class="row" style="min-height: 70vh;">
      <div class="col-md-12">
         <div class="card">
            <div class="card-header">
               <h3 class="mb-0 card-title">Edit Patient</h3>
            </div>
            <div class="card-body">
               @if ($message = Session::get('status'))
               <div class="alert alert-success">
                  <p></p>
               </div>
               @endif
            </div>
            <div class="col-lg-12">
               @if ($errors->any())
               <div class="alert alert-danger">
                  <strong>Whoops!</strong> There were some problems with your input.<br><br>
                  <ul>
                     @foreach ($errors->all() as $error)
                     <li>{{ $error }}</li>
                     @endforeach
                  </ul>
               </div>
               @endif
               <form action="{{route('patients.update',['id'=>$patient->id])}}" method="POST" enctype="multipart/form-data">
                 @csrf
                @method('PUT')


<div class="row">
<div class="col-md-6">
    <div class="form-group">
        <label class="form-label">Patient Code</label>
        <input type="text" class="form-control" required name="patient_code"  value="{{$patient->patient_code}}" placeholder="Patient Code">
    </div>
</div>


                    <div class="col-md-6">
    <div class="form-group">
        <label class="form-label">Patient Name</label>
        <input type="text" class="form-control" required name="patient_name"   value="{{$patient->patient_name}}" placeholder="Patient Name">
    </div>
</div>

<div class="col-md-6">
    <div class="form-group">
        <label class="form-label">Patient Email</label>
        <input type="email" class="form-control" required name="patient_email" value="{{$patient->patient_email}}"  placeholder="Patient Email">
    </div>
</div>

<div class="col-md-6">
    <div class="form-group">
        <label class="form-label">Patient Mobile</label>
        <input type="text" class="form-control" required name="patient_mobile" value="{{$patient->patient_mobile}}"  placeholder="Patient Mobile">
    </div>
</div>

<div class="col-md-6">
    <div class="form-group">
        <label class="form-label">Patient Address</label>
        <input type="text" class="form-control" required name="patient_address" value="{{$patient->patient_address}}"  placeholder="Patient Address">
    </div>
</div>


                  <div class="form-group">
    <label for="patient_gender">Gender</label>
    <select class="form-control" name="patient_gender" id="patient_gender">
        <option value="">Choose Gender</option>
        @foreach($gender as $id => $gender)
            <option value="{{ $id }}">{{ $gender }}</option>
        @endforeach
    </select>
</div>


                     <div class="col-md-6">
                        <div class="form-group">
                           <label class="form-label">Patient Dob</label>
                           <input type="date" class="form-control" required name="patient_dob"  value="{{$patient->patient_dob}}" placeholder="Patient Dob">
                        </div>
                     </div>

                     <div class="form-group">
                    <label for="available_membership">Membership</label>
                     <select class="form-control" name="available_membership" id="available_membership">
                      <option value="">Choose Membership</option>
                          @foreach($membership as $id => $membership)
                              <option value="{{ $id }}">{{ $membership }}</option>
                          @endforeach
                     </select>
                  </div>


                     <div class="col-md-6">
                        <div class="form-group">
                           <label class="form-label">Username</label>
                           <input type="text" class="form-control" required name="username" value="{{$patient->username}}"   placeholder="User Name">
                        </div>
                     </div>


                     <div class="col-md-6">
                        <div class="form-group">
                           <label class="form-label">Password</label>
                           <input type="text" class="form-control" required name="password"  placeholder="Password">
                        </div>
                     </div>
  <!-- ... -->
                      
<div class="col-md-6">
   <div class="form-group">
      <div class="form-label">Status</div>
      <label class="custom-switch">
         <input type="hidden" name="is_active" value="0"> <!-- Hidden field for false value -->
         <input type="checkbox" id="is_active" name="is_active" onchange="toggleStatus(this)" class="custom-switch-input" checked>
         <span id="statusLabel" class="custom-switch-indicator"></span>
         <span id="statusText" class="custom-switch-description">Active</span>
      </label>
   </div>
</div>
</div>

<!-- ... -->

                  


                        <div class="form-group">
                           <center>
                           <button type="submit" class="btn btn-raised btn-primary">
                           <i class="fa fa-check-square-o"></i> Add</button>
                           <button type="reset" class="btn btn-raised btn-success">
                           Reset</button>
                           <a class="btn btn-danger" href="{{route('patients.index')}}">Cancel</a>
                           </center>
                        </div>
                     </div>
                  </div>

               </form>

      </div>
   </div>
</div>


@endsection
@section('js')
<script>
    function toggleStatus(checkbox) {
        if (checkbox.checked) {
            $("#statusText").text('Active');
            $("input[name=is_active]").val(1); // Set the value to 1 when checked
        } else {
            $("#statusText").text('Inactive');
            $("input[name=is_active]").val(0); // Set the value to 0 when unchecked
        }
    }
</script>


@endsection
