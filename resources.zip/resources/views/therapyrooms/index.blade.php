@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-12 col-lg-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Manage Therapy Room</h3>
            </div>
            <div class="card-body">
                <a href="{{ route('therapyrooms.create') }}" class="btn btn-block btn-info">
                    <i class="fa fa-plus"></i>
                    Create Therapy Room
                </a>
                
               
                
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered text-nowrap w-100">
                            <thead>
                                <tr>
                                    <th class="wd-15p">SL.NO</th>
                                    <th class="wd-15p">Branch</th>
                                    <th class="wd-20p">Room Name</th>
                                    <th class="wd-15p">Status</th>
                                    <th class="wd-15p">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                $i = 0;
                                @endphp
                                @foreach($therapyrooms as $therapyroom)
                                <tr>
                                    <td>{{ ++$i }}</td>
                                    <td>{{ $therapyroom->branch->branch_name }}</td>
                                    <td>{{ $therapyroom->room_name }}</td>
                                   
                                    <td>
                                         <form action="{{ route('therapyrooms.changeStatus', $therapyroom->id) }}" method="POST">
                                        @csrf
                                        @method('PATCH')

                                            <button type="submit"
                                                onclick="return confirm('Do you want to Change status?');"
                                                class="btn btn-sm @if($therapyroom->is_active == 0) btn-danger @else btn-success @endif">
                                                @if($therapyroom->is_active == 0)
                                                InActive
                                                @else
                                                Active
                                                @endif
                                            </button>
                                        </form>
                                    </td>
                                       
                                    <td>
                                        <a class="btn btn-secondary"
                                            href="{{ route('therapyrooms.edit', $therapyroom->id) }}"><i
                                                class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit </a>
                                        <form style="display: inline-block"
                                            action="{{ route('therapyrooms.destroy', $therapyroom->id) }}" method="post">
                                            @csrf
                                            @method('delete')
                                            <button type="submit" class="btn btn-danger"><i class="fa fa-trash"
                                                    aria-hidden="true"></i>Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                
                <!-- TABLE WRAPPER -->
            </div>
            <!-- SECTION WRAPPER -->
        </div>
    </div>
</div>
<!-- ROW-1 CLOSED -->
@endsection



